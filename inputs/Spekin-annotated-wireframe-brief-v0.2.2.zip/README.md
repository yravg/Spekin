# Spekin annotated wireframe brief v0.2.2
22 Nov 2026 · Asia/Shanghai UTC+8

Open index.html offline. This source-to-screen brief reuses unchanged approved Design Desk BW SVGs; it is NOT a competing final screen revision. Current evening Design Desk work was not accessible in inspected shared files/own transcript. Reconcile it before replacing drawings.

Eight approved flow screens are distinct from eight workflow stages. Shell overlay and annotations specify proposed changes. Existing Studio/DPAI canvas/buttons are owner-reported baseline, exact controls pending inventory. Per-region source/confidence and reuse actions are in index.html and annotations.json. All SVG text remains editable. Edit HTML/JSON/SVG in a text/vector editor; contenteditable note changes in the browser are temporary unless saved. No network dependencies, images/fonts/scripts from competitors, product runtime, or app code are included. The historical baseline Python generator is not included or used.

Contents: index.html; annotations.json; frames.json; baseline/*.svg (17 unchanged vectors); PDF; checksums and render checks. Some source links require Drive access when online; the drawings and notes themselves work offline. Original pack: https://drive.google.com/file/d/1PmMe8SX_KlL4RPlYQae9_6bQSWpzapb9/view ; prior PDF: https://drive.google.com/file/d/11efio78CZ4ZSabGCneTHaPVu__U3HFom/view .
